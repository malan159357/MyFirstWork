<template>
  <div class="app-container">
   代码生成
  </div>
</template>